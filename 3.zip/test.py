import suprocess as sp 

cidr = input ('Enter the cidr')

subnets = input ('Enter the subnet number')
print (f"given cidr is {cidr} & number of subnets is {subnets}")

command1= "terraform plan"
commnad2= "terraform apply --auto-approve"

out=sp.call(command1, shell=True)

if out==0;
sp.call  (command2, shell=True)